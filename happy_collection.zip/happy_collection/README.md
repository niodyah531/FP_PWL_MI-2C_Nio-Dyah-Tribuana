1 . Jalankan Composer Install atau composer Update
2 . Copy .env.example lalu setting sesuai database
3 . jalankan php artisan migrate atau import data base via phpmyadmin ( file sql ada di projek )
4 . jalankan php artisan db:seed (harus terkoneksi dengan internet soalnya mengambil data dari api raja ongkir)
